<footer class="footer" style="position: absolute; bottom: 0; width: -webkit-fill-available;">
    <div class="container-fluid">
        <div class="row">
            <div class="credits ml-auto">
              <span class="copyright">
                © 2021, made with <i class="fa fa-heart heart"></i>
              </span>
            </div>
        </div>
    </div>
</footer>
