<a href="{{$detail_url}}" class="btn btn-success"> <i class="nc-icon nc-tile-56"></i> Detail</a>
<a href="{{$delete_url}}" class="btn btn-danger"> <i class="nc-icon nc-simple-remove"></i> Hapus</a>
