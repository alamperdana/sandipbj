<a href="{{$add_url}}" class="btn btn-info"> <i class="nc-icon nc-simple-add"></i> Tambah</a>
