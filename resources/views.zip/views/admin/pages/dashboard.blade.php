<div class="row">
    <div class="col-md-12">
        <h3 class="description">{{ $data }}</h3>
    </div>
</div>
