<div class="col-md-6">
    <div class="card card-user">
        <div class="card-header">
            <h5 class="card-title">Keterangan</h5>
            <textarea class="form-control textarea" name="keterangan"></textarea>
        </div>
        <div class="card-body">
        </div>
    </div>
</div>
